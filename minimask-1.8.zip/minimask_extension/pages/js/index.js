/**
 * JS function for iondex.html
 */

//Add click to buttons
addButtonOnClick('id_btn_newwallet', function(e) {
	jumpToPage("newwallet.html");
});

addButtonOnClick('id_btn_restorewallet', function(e) {
	jumpToPage("createwallet.html");
});

